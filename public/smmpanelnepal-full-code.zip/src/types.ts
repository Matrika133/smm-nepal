export type ServiceCategory =
  | 'Instagram'
  | 'TikTok'
  | 'YouTube'
  | 'Facebook'
  | 'Telegram'
  | 'X (Twitter)'
  | 'Spotify'
  | 'LinkedIn'
  | 'Discord'
  | 'Website Traffic';

export type ServiceType =
  | 'Followers'
  | 'Likes'
  | 'Views'
  | 'Comments'
  | 'Subscribers'
  | 'Watch Time'
  | 'Shares / Retweets'
  | 'Members'
  | 'Live Stream'
  | 'Custom Comments';

export interface SMMService {
  id: string;
  serviceId: number;
  name: string;
  category: ServiceCategory;
  type: ServiceType;
  ratePer1k: number; // in NPR (Nepalese Rupees)
  minQuantity: number;
  maxQuantity: number;
  averageTime: string;
  speed: string;
  description: string;
  refill: boolean;
  refillDays?: number;
  guaranteed: boolean;
  dripFeedAvailable: boolean;
  cancelAvailable: boolean;
  isPopular?: boolean;
}

export type OrderStatus =
  | 'Pending'
  | 'In progress'
  | 'Processing'
  | 'Completed'
  | 'Partial'
  | 'Canceled'
  | 'Refunded';

export interface SMMOrder {
  id: string;
  orderId: number;
  serviceId: string;
  serviceName: string;
  category: ServiceCategory;
  link: string;
  quantity: number;
  charge: number; // in NPR
  startCount: number;
  remains: number;
  status: OrderStatus;
  createdAt: string;
  dripFeed?: {
    runs: number;
    intervalMinutes: number;
    completedRuns: number;
  };
  customComments?: string[];
}

export interface UserAccount {
  id: string;
  username: string;
  email: string;
  fullName?: string;
  phone?: string;
  password?: string;
  balance: number; // in NPR
  currency: 'NPR';
  tier: 'Standard' | 'Reseller' | 'VIP' | 'Wholesale';
  apiKey: string;
  totalSpent: number; // in NPR
  totalOrders: number;
  avatarUrl?: string;
  createdAt?: string;
}

export interface LoginFormData {
  usernameOrEmail: string;
  password: string;
  rememberMe?: boolean;
}

export interface RegisterFormData {
  fullName: string;
  username: string;
  email: string;
  phone: string;
  password: string;
  confirmPassword: string;
  tier?: 'Standard' | 'Reseller' | 'VIP';
  referralCode?: string;
}

export interface PaymentTransaction {
  id: string;
  userId?: string;
  type?: 'Deposit' | 'Debit' | 'Refund' | 'Commission';
  method:
    | 'Fonepay'
    | 'eSewa'
    | 'Khalti'
    | 'Bank Transfer (ConnectIPS)'
    | 'IME Pay'
    | 'Crypto (USDT TRC20)'
    | 'Wallet Debit'
    | 'Child Panel Hosting'
    | 'Referral Bonus'
    | string;
  amount: number; // in NPR
  currency: 'NPR';
  fee: number;
  status: 'Completed' | 'Pending' | 'Failed' | 'Refunded';
  transactionId: string;
  senderName?: string;
  senderPhone?: string;
  screenshotUrl?: string;
  notes?: string;
  date: string;
}

export interface SupportTicket {
  id: string;
  ticketNumber: number;
  subject: string;
  orderId?: number;
  status: 'Open' | 'Answered' | 'Closed';
  priority: 'Low' | 'Medium' | 'High';
  createdAt: string;
  updatedAt: string;
  messages: {
    sender: 'user' | 'support' | 'ai_agent';
    text: string;
    timestamp: string;
  }[];
}

export interface BroadcastNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'deal';
  date: string;
}

export interface ToastNotification {
  id: string;
  orderId: number;
  serviceName: string;
  previousStatus: OrderStatus;
  newStatus: OrderStatus;
  title: string;
  message: string;
  timestamp: string;
  type: 'in_progress' | 'completed' | 'info' | 'warning';
}

export type ChildPanelTheme =
  | 'Dark Cyber'
  | 'Neon Emerald'
  | 'Minimalist Slate'
  | 'Royal Purple'
  | 'Ocean Blue';

export type ChildPanelStatus =
  | 'Active'
  | 'Pending DNS'
  | 'Configuring'
  | 'Expired'
  | 'Suspended';

export interface ChildPanel {
  id: string;
  userId?: string;
  domain: string;
  adminUsername: string;
  adminPassword?: string;
  currency: 'NPR' | 'USD' | 'INR';
  priceMonthly: number; // in NPR
  status: ChildPanelStatus;
  nameservers: {
    ns1: string;
    ns2: string;
  };
  cnameRecord: string;
  createdAt: string;
  renewDate: string;
  autoRenew: boolean;
  theme: ChildPanelTheme;
  totalOrdersForwarded: number;
  totalEarningsNPR: number;
  dnsVerified: boolean;
  lastDnsCheck?: string;
  profitMarginPercent: number; // e.g. 25 for +25% markup
  siteTitle: string;
  supportContact: string;
  syncedServicesCount: number;
}
