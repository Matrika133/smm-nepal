import React, { useState, useRef } from 'react';
import {
  Wallet,
  QrCode,
  ShieldCheck,
  Zap,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  History,
  Upload,
  Image as ImageIcon,
  X,
  Eye,
  Download,
  Phone,
  Building,
  Sparkles,
  ArrowRight,
  RefreshCw,
  FileCheck,
  Clock
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PaymentTransaction, UserAccount } from '../types';

interface AddFundsTabProps {
  user: UserAccount;
  transactions: PaymentTransaction[];
  onAddFunds: (
    amount: number,
    method: PaymentTransaction['method'],
    txId: string,
    extra?: {
      senderName?: string;
      senderPhone?: string;
      screenshotUrl?: string;
      notes?: string;
      isImmediateApproval?: boolean;
    }
  ) => void;
  onApproveDeposit?: (txId: string) => void;
  onNavigateToTransactions?: () => void;
}

export function AddFundsTab({ user, transactions, onAddFunds, onApproveDeposit, onNavigateToTransactions }: AddFundsTabProps) {
  const [selectedMethod, setSelectedMethod] = useState<PaymentTransaction['method']>('Fonepay');
  const [depositAmount, setDepositAmount] = useState<number>(1000);
  const [transactionCode, setTransactionCode] = useState('');
  const [senderName, setSenderName] = useState('');
  const [senderPhone, setSenderPhone] = useState('');
  const [notes, setNotes] = useState('');

  // Screenshot upload state
  const [screenshotDataUrl, setScreenshotDataUrl] = useState<string | null>(null);
  const [screenshotFileName, setScreenshotFileName] = useState<string>('');
  const [screenshotFileSize, setScreenshotFileSize] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);

  // Modals & tooltips
  const [previewImageModal, setPreviewImageModal] = useState<string | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Copy helper
  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  // Process screenshot file
  const handleFileSelection = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (PNG, JPG, JPEG, WEBP).');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setErrorMsg('File size exceeds 10MB limit. Please upload a smaller screenshot.');
      return;
    }

    setErrorMsg('');
    setScreenshotFileName(file.name);
    setScreenshotFileSize((file.size / 1024).toFixed(1) + ' KB');

    const reader = new FileReader();
    reader.onload = () => {
      setScreenshotDataUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelection(e.target.files[0]);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelection(e.dataTransfer.files[0]);
    }
  };

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (depositAmount < 50) {
      setErrorMsg('Minimum deposit amount is Rs. 50 NPR.');
      return;
    }

    if (!transactionCode.trim()) {
      setErrorMsg('Please enter the Transaction ID / Ref Number from your payment app.');
      return;
    }

    // Submit deposit request for manual verification
    onAddFunds(depositAmount, selectedMethod, transactionCode.trim(), {
      senderName: senderName.trim() || undefined,
      senderPhone: senderPhone.trim() || undefined,
      screenshotUrl: screenshotDataUrl || undefined,
      notes: notes.trim() || undefined,
      isImmediateApproval: false,
    });

    setSuccessMsg(
      `Deposit request of Rs. ${depositAmount.toLocaleString()} NPR via ${selectedMethod} (Ref #${transactionCode.trim()}) has been submitted for manual verification. Our finance desk is cross-checking the payment details. Funds will be credited upon verification.`
    );

    // Reset form
    setTransactionCode('');
    setSenderName('');
    setSenderPhone('');
    setNotes('');
    setScreenshotDataUrl(null);
    setScreenshotFileName('');
    setScreenshotFileSize('');
  };

  // Payment Details according to selected method
  const getMethodDetails = () => {
    switch (selectedMethod) {
      case 'Fonepay':
        return {
          title: 'Fonepay QR (All Nepal Banks & Wallets)',
          merchantName: 'SMM PANEL NEPAL (PVT. LTD.)',
          merchantId: 'FONEPAY-MERCHANT-9801234567',
          phone: '9801234567',
          instructions: 'Scan with ANY Nepal Mobile Banking App (Nabil, Global IME, NIC Asia, Siddhartha, Sanima, Prabhu, etc.) or Fonepay app.',
          qrColor: 'from-red-600 to-rose-700',
          badge: 'All Banks QR',
        };
      case 'eSewa':
        return {
          title: 'eSewa Mobile Wallet Direct QR',
          merchantName: 'SMM PANEL NEPAL OFFICIAL',
          merchantId: '9801234567',
          phone: '9801234567',
          instructions: 'Scan with eSewa App or send directly to eSewa ID: 9801234567. Use remarks "SMM".',
          qrColor: 'from-emerald-600 to-green-700',
          badge: 'eSewa ID',
        };
      case 'Khalti':
        return {
          title: 'Khalti Digital Wallet Direct QR',
          merchantName: 'SMM PANEL NEPAL',
          merchantId: '9819876543',
          phone: '9819876543',
          instructions: 'Scan with Khalti App or transfer to Khalti ID: 9819876543.',
          qrColor: 'from-purple-600 to-indigo-700',
          badge: 'Khalti ID',
        };
      case 'Bank Transfer (ConnectIPS)':
        return {
          title: 'Direct Bank Transfer / ConnectIPS',
          merchantName: 'SMM PANEL NEPAL PVT. LTD.',
          merchantId: 'A/C: 0192837461928301',
          phone: 'Nabil Bank Ltd. (Baneshwor Branch)',
          instructions: 'Transfer via ConnectIPS or Mobile Banking. Account No: 0192837461928301 | Branch: New Baneshwor, Kathmandu.',
          qrColor: 'from-blue-600 to-cyan-700',
          badge: 'ConnectIPS / Bank',
        };
      case 'IME Pay':
        return {
          title: 'IME Pay Digital Wallet',
          merchantName: 'SMM NEPAL PVT. LTD.',
          merchantId: '9841002233',
          phone: '9841002233',
          instructions: 'Transfer to IME Pay Wallet: 9841002233.',
          qrColor: 'from-red-700 to-amber-700',
          badge: 'IME Pay',
        };
      default:
        return {
          title: 'USDT (TRC-20 Network)',
          merchantName: 'Crypto Auto Deposit',
          merchantId: 'TQn9Y2khEsL8N74fSMMNepalCrypto9x811b',
          phone: 'TRC-20 Network Only',
          instructions: 'Transfer USDT to TRC-20 address. Auto-credited in NPR equivalent (Rate $1 = Rs. 135).',
          qrColor: 'from-teal-600 to-emerald-700',
          badge: 'USDT TRC20',
        };
    }
  };

  const details = getMethodDetails();

  return (
    <div className="space-y-6">
      {/* Top Banner / User Balance */}
      <div className="bg-neutral-900/90 border border-neutral-800/90 rounded-2xl p-5 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Wallet className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              Add Funds (NPR) • Nepal Instant QR Gateway
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-bold">
                0% Processing Fee
              </span>
            </h2>
            <p className="text-xs text-neutral-400">
              Pay using Fonepay QR, eSewa, Khalti, Mobile Banking, or ConnectIPS, and upload your payment screenshot.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 bg-neutral-950 px-4 py-2.5 rounded-xl border border-neutral-800 w-full sm:w-auto justify-between sm:justify-end">
          <span className="text-xs text-neutral-400">Current Balance:</span>
          <span className="text-base font-mono font-black text-emerald-400">
            Rs. {user.balance.toLocaleString()} <span className="text-xs text-neutral-400 font-normal">NPR</span>
          </span>
        </div>
      </div>

      {/* Main 2-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Payment QR Code & Merchant Information (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-neutral-900/90 border border-neutral-800/90 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center gap-2">
                <QrCode className="w-4 h-4 text-emerald-400" />
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                  Official Merchant QR Code
                </h3>
              </div>
              <span className="text-[10px] text-emerald-400 font-mono font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                Instant Auto-Verification
              </span>
            </div>

            {/* Gateway Selection Chips */}
            <div className="grid grid-cols-3 gap-1.5">
              {(
                [
                  'Fonepay',
                  'eSewa',
                  'Khalti',
                  'Bank Transfer (ConnectIPS)',
                  'IME Pay',
                  'Crypto (USDT TRC20)',
                ] as const
              ).map((method) => (
                <button
                  key={method}
                  type="button"
                  onClick={() => setSelectedMethod(method)}
                  className={`p-2 rounded-xl text-left border transition cursor-pointer flex flex-col justify-between ${
                    selectedMethod === method
                      ? 'bg-emerald-950/40 border-emerald-500 text-white shadow-sm shadow-emerald-500/20'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700 hover:text-neutral-200'
                  }`}
                >
                  <span className="text-[11px] font-bold truncate block">
                    {method === 'Fonepay' && '🔴 Fonepay'}
                    {method === 'eSewa' && '🟢 eSewa'}
                    {method === 'Khalti' && '🟣 Khalti'}
                    {method === 'Bank Transfer (ConnectIPS)' && '🏛️ Bank/IPS'}
                    {method === 'IME Pay' && '🟠 IME Pay'}
                    {method === 'Crypto (USDT TRC20)' && '🌐 USDT'}
                  </span>
                  <span className="text-[9px] text-neutral-500 truncate mt-0.5">
                    {method === 'Fonepay' && 'All Banks'}
                    {method === 'eSewa' && 'Wallet'}
                    {method === 'Khalti' && 'Wallet'}
                    {method === 'Bank Transfer (ConnectIPS)' && 'ConnectIPS'}
                    {method === 'IME Pay' && 'Mobile Money'}
                    {method === 'Crypto (USDT TRC20)' && 'TRC-20'}
                  </span>
                </button>
              ))}
            </div>

            {/* The QR Code Card Display */}
            <div className="relative rounded-2xl bg-white p-5 shadow-2xl flex flex-col items-center justify-center text-neutral-950 overflow-hidden border-4 border-neutral-800">
              {/* Top QR Header */}
              <div className="w-full flex items-center justify-between border-b border-neutral-200 pb-2.5 mb-3">
                <div className="flex items-center gap-1.5">
                  <div className="h-6 w-6 rounded-md bg-neutral-950 flex items-center justify-center text-emerald-400">
                    <Zap className="w-3.5 h-3.5 fill-emerald-400 text-emerald-400" />
                  </div>
                  <span className="text-xs font-black tracking-tight text-neutral-900">
                    SMM PANEL NEPAL
                  </span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  {details.badge}
                </span>
              </div>

              {/* QR Image Area */}
              <div className="relative p-2 bg-neutral-50 rounded-xl border border-neutral-200 shadow-inner group">
                <div className="w-52 h-52 sm:w-56 sm:h-56 flex flex-col items-center justify-center bg-white p-2 relative rounded-lg">
                  {/* SVG Stylized QR Pattern */}
                  <svg viewBox="0 0 200 200" className="w-full h-full text-neutral-900">
                      {/* Corner Outer and Inner Markers */}
                      {/* Top-Left */}
                      <rect x="10" y="10" width="50" height="50" fill="currentColor" rx="6" />
                      <rect x="18" y="18" width="34" height="34" fill="#ffffff" rx="4" />
                      <rect x="25" y="25" width="20" height="20" fill="currentColor" rx="3" />

                      {/* Top-Right */}
                      <rect x="140" y="10" width="50" height="50" fill="currentColor" rx="6" />
                      <rect x="148" y="18" width="34" height="34" fill="#ffffff" rx="4" />
                      <rect x="155" y="25" width="20" height="20" fill="currentColor" rx="3" />

                      {/* Bottom-Left */}
                      <rect x="10" y="140" width="50" height="50" fill="currentColor" rx="6" />
                      <rect x="18" y="148" width="34" height="34" fill="#ffffff" rx="4" />
                      <rect x="25" y="155" width="20" height="20" fill="currentColor" rx="3" />

                      {/* Synchronized QR Data Matrix Dots */}
                      <g fill="currentColor">
                        {/* Top rows */}
                        <rect x="68" y="12" width="8" height="8" rx="2" />
                        <rect x="80" y="12" width="16" height="8" rx="2" />
                        <rect x="104" y="12" width="8" height="8" rx="2" />
                        <rect x="120" y="12" width="12" height="8" rx="2" />

                        <rect x="68" y="24" width="14" height="8" rx="2" />
                        <rect x="90" y="24" width="18" height="8" rx="2" />
                        <rect x="116" y="24" width="8" height="8" rx="2" />

                        <rect x="68" y="36" width="8" height="8" rx="2" />
                        <rect x="84" y="36" width="8" height="8" rx="2" />
                        <rect x="100" y="36" width="24" height="8" rx="2" />

                        <rect x="68" y="48" width="20" height="8" rx="2" />
                        <rect x="96" y="48" width="8" height="8" rx="2" />
                        <rect x="112" y="48" width="16" height="8" rx="2" />

                        {/* Middle Matrix */}
                        <rect x="12" y="68" width="16" height="8" rx="2" />
                        <rect x="36" y="68" width="8" height="8" rx="2" />
                        <rect x="52" y="68" width="12" height="8" rx="2" />
                        <rect x="72" y="68" width="8" height="8" rx="2" />
                        <rect x="88" y="68" width="24" height="8" rx="2" />
                        <rect x="120" y="68" width="8" height="8" rx="2" />
                        <rect x="136" y="68" width="20" height="8" rx="2" />
                        <rect x="164" y="68" width="24" height="8" rx="2" />

                        <rect x="12" y="80" width="8" height="8" rx="2" />
                        <rect x="28" y="80" width="20" height="8" rx="2" />
                        <rect x="56" y="80" width="8" height="8" rx="2" />
                        <rect x="72" y="80" width="16" height="8" rx="2" />
                        <rect x="112" y="80" width="16" height="8" rx="2" />
                        <rect x="136" y="80" width="8" height="8" rx="2" />
                        <rect x="152" y="80" width="16" height="8" rx="2" />
                        <rect x="176" y="80" width="12" height="8" rx="2" />

                        {/* Center Brand Badge Space */}
                        <rect x="12" y="96" width="24" height="8" rx="2" />
                        <rect x="44" y="96" width="16" height="8" rx="2" />
                        <rect x="140" y="96" width="16" height="8" rx="2" />
                        <rect x="164" y="96" width="24" height="8" rx="2" />

                        <rect x="12" y="112" width="12" height="8" rx="2" />
                        <rect x="32" y="112" width="8" height="8" rx="2" />
                        <rect x="48" y="112" width="16" height="8" rx="2" />
                        <rect x="136" y="112" width="24" height="8" rx="2" />
                        <rect x="168" y="112" width="20" height="8" rx="2" />

                        <rect x="12" y="124" width="24" height="8" rx="2" />
                        <rect x="44" y="124" width="8" height="8" rx="2" />
                        <rect x="60" y="124" width="12" height="8" rx="2" />
                        <rect x="80" y="124" width="16" height="8" rx="2" />
                        <rect x="104" y="124" width="8" height="8" rx="2" />
                        <rect x="120" y="124" width="20" height="8" rx="2" />
                        <rect x="148" y="124" width="12" height="8" rx="2" />
                        <rect x="168" y="124" width="20" height="8" rx="2" />

                        {/* Bottom rows */}
                        <rect x="68" y="140" width="16" height="8" rx="2" />
                        <rect x="92" y="140" width="16" height="8" rx="2" />
                        <rect x="116" y="140" width="24" height="8" rx="2" />
                        <rect x="148" y="140" width="8" height="8" rx="2" />
                        <rect x="164" y="140" width="24" height="8" rx="2" />

                        <rect x="68" y="152" width="8" height="8" rx="2" />
                        <rect x="84" y="152" width="24" height="8" rx="2" />
                        <rect x="116" y="152" width="8" height="8" rx="2" />
                        <rect x="132" y="152" width="16" height="8" rx="2" />
                        <rect x="156" y="152" width="12" height="8" rx="2" />
                        <rect x="176" y="152" width="12" height="8" rx="2" />

                        <rect x="68" y="164" width="20" height="8" rx="2" />
                        <rect x="96" y="164" width="12" height="8" rx="2" />
                        <rect x="116" y="164" width="24" height="8" rx="2" />
                        <rect x="148" y="164" width="16" height="8" rx="2" />
                        <rect x="172" y="164" width="16" height="8" rx="2" />

                        <rect x="68" y="176" width="12" height="8" rx="2" />
                        <rect x="88" y="176" width="16" height="8" rx="2" />
                        <rect x="112" y="176" width="8" height="8" rx="2" />
                        <rect x="128" y="176" width="20" height="8" rx="2" />
                        <rect x="156" y="176" width="8" height="8" rx="2" />
                        <rect x="172" y="176" width="16" height="8" rx="2" />
                      </g>

                      {/* Center Brand Emblem */}
                      <circle cx="100" cy="100" r="22" fill="#ffffff" stroke="#10b981" strokeWidth="2.5" />
                      <text
                        x="100"
                        y="104"
                        textAnchor="middle"
                        fontSize="9"
                        fontWeight="900"
                        fill="#047857"
                        fontFamily="sans-serif"
                      >
                        NEPAL
                      </text>
                    </svg>
                  </div>

                {/* Scan Overlay Badge */}
                <div className="mt-2 text-center">
                  <span className="text-[11px] font-black text-neutral-800 uppercase tracking-wide">
                    SCAN & PAY WITH ANY NEPAL APP
                  </span>
                </div>
              </div>

              {/* Merchant Details below QR */}
              <div className="w-full mt-3 pt-2.5 border-t border-neutral-200 text-center space-y-1">
                <div className="text-xs font-black text-neutral-900 truncate">
                  {details.merchantName}
                </div>
                <div className="text-[11px] font-mono text-neutral-600 truncate flex items-center justify-center gap-1.5">
                  <span>{details.merchantId}</span>
                  <button
                    type="button"
                    onClick={() => handleCopy(details.merchantId, 'merchantId')}
                    className="p-1 text-emerald-700 hover:text-emerald-900 cursor-pointer"
                    title="Copy Account ID"
                  >
                    {copiedField === 'merchantId' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Copy Info Rows */}
            <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 text-xs space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-neutral-400">Account / Mobile No:</span>
                <div className="flex items-center gap-1.5">
                  <span className="font-mono text-white font-bold">{details.phone}</span>
                  <button
                    type="button"
                    onClick={() => handleCopy(details.phone, 'phone')}
                    className="p-1 hover:text-emerald-400 text-neutral-400 transition cursor-pointer"
                    title="Copy Phone/Account"
                  >
                    {copiedField === 'phone' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-neutral-400">Payment Remarks:</span>
                <span className="font-mono text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded">
                  {user.username}
                </span>
              </div>

              <p className="text-[11px] text-neutral-400 font-sans pt-1 border-t border-neutral-800/80 leading-relaxed">
                💡 {details.instructions}
              </p>
            </div>
          </div>
        </div>

        {/* Right: Payment Submission Form & Screenshot Upload (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-neutral-900/90 border border-neutral-800/90 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3.5">
              <div>
                <h3 className="text-sm font-bold text-white tracking-wide">
                  Deposit Verification Form
                </h3>
                <p className="text-xs text-neutral-400">
                  Submit your payment transaction details and screenshot for verification.
                </p>
              </div>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-emerald-400 font-semibold">
                NPR Gateway
              </span>
            </div>

            <form onSubmit={handleDepositSubmit} className="space-y-4">
              {/* Deposit Amount (NPR) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-neutral-300">
                    1. Deposit Amount (NPR)
                  </label>
                  <span className="text-[11px] text-neutral-400 font-mono">
                    Min: <strong className="text-white">Rs. 50</strong> • Max: <strong className="text-white">Rs. 100,000</strong>
                  </span>
                </div>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-500 font-mono text-xs font-bold">
                    Rs.
                  </span>
                  <input
                    id="input-deposit-amount"
                    type="number"
                    min={50}
                    max={100000}
                    step={10}
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(Number(e.target.value))}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white font-mono font-bold focus:outline-none focus:border-emerald-500 transition"
                  />
                </div>

                {/* Quick Amount Chips */}
                <div className="flex flex-wrap gap-1.5 pt-0.5">
                  {[500, 1000, 2500, 5000, 10000].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setDepositAmount(amt)}
                      className={`px-3 py-1 rounded-lg text-xs font-mono transition cursor-pointer ${
                        depositAmount === amt
                          ? 'bg-emerald-500 text-neutral-950 font-bold'
                          : 'bg-neutral-950 hover:bg-neutral-800 text-neutral-300 border border-neutral-800'
                      }`}
                    >
                      Rs. {amt.toLocaleString()}
                    </button>
                  ))}
                </div>
              </div>

              {/* Transaction ID & Sender Information */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-neutral-300">
                    2. Transaction ID / Reference No. <span className="text-red-400">*</span>
                  </label>
                  <input
                    id="input-transaction-id"
                    type="text"
                    required
                    placeholder="e.g. FONEPAY-9821034 or 8812903"
                    value={transactionCode}
                    onChange={(e) => setTransactionCode(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-white font-mono focus:outline-none focus:border-emerald-500 transition"
                  />
                  <span className="text-[10px] text-neutral-500 block">Found in payment app receipt</span>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-neutral-300">
                    3. Sender Mobile No. / Name
                  </label>
                  <input
                    id="input-sender-info"
                    type="text"
                    placeholder="e.g. 9841XXXXXX or Bikash"
                    value={senderPhone}
                    onChange={(e) => setSenderPhone(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-xs text-white font-mono focus:outline-none focus:border-emerald-500 transition"
                  />
                  <span className="text-[10px] text-neutral-500 block">Helps speed up instant verification</span>
                </div>
              </div>

              {/* Section to Upload Payment Screenshot */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-neutral-300 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
                    4. Attach Payment Screenshot Proof
                  </span>
                  <span className="text-[10px] text-emerald-400 font-mono">
                    PNG, JPG, WEBP (Max 10MB)
                  </span>
                </label>

                {screenshotDataUrl ? (
                  /* Screenshot Preview Box */
                  <div className="p-3.5 rounded-xl bg-neutral-950 border border-emerald-500/40 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={screenshotDataUrl}
                        alt="Payment Screenshot Preview"
                        onClick={() => setPreviewImageModal(screenshotDataUrl)}
                        className="h-14 w-14 object-cover rounded-lg border border-neutral-700 cursor-pointer hover:opacity-80 transition shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-white truncate">
                          {screenshotFileName}
                        </div>
                        <div className="text-[11px] text-neutral-400 font-mono">
                          {screenshotFileSize} • Ready for upload
                        </div>
                        <button
                          type="button"
                          onClick={() => setPreviewImageModal(screenshotDataUrl)}
                          className="text-[11px] text-emerald-400 hover:underline flex items-center gap-1 mt-0.5 cursor-pointer"
                        >
                          <Eye className="w-3 h-3" /> View full screenshot
                        </button>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setScreenshotDataUrl(null);
                        setScreenshotFileName('');
                        setScreenshotFileSize('');
                        if (fileInputRef.current) fileInputRef.current.value = '';
                      }}
                      className="p-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-red-400 transition cursor-pointer"
                      title="Remove Screenshot"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  /* Dropzone Uploader */
                  <div
                    onDragOver={(e) => {
                      e.preventDefault();
                      setIsDragging(true);
                    }}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                    className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition flex flex-col items-center justify-center gap-2 ${
                      isDragging
                        ? 'border-emerald-500 bg-emerald-950/20 text-emerald-300'
                        : 'border-neutral-800 hover:border-neutral-700 bg-neutral-950/60 text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    <div className="h-10 w-10 rounded-full bg-neutral-900 flex items-center justify-center text-emerald-400 mb-1 border border-neutral-800">
                      <Upload className="w-5 h-5" />
                    </div>
                    <div className="text-xs font-semibold text-neutral-200">
                      Click to upload payment screenshot or drag & drop here
                    </div>
                    <p className="text-[11px] text-neutral-500 font-mono">
                      eSewa, Khalti, or Mobile Banking payment receipt image
                    </p>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileInputChange}
                      className="hidden"
                    />
                  </div>
                )}
              </div>

              {/* Optional Notes */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-neutral-300">
                  5. Additional Remarks / Note (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Paid from Nabil Bank app or Urgently need for TikTok boost"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Total Summary & Submit Button */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-950/30 via-neutral-950 to-neutral-950 border border-emerald-500/25 flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-4">
                <div>
                  <span className="text-[11px] text-neutral-400 block">Total Balance to Credit (After Verification)</span>
                  <span className="text-xl font-mono font-black text-emerald-400">
                    +Rs. {depositAmount.toLocaleString()}{' '}
                    <span className="text-xs text-neutral-400 font-normal font-sans">NPR</span>
                  </span>
                </div>

                <button
                  id="btn-confirm-npr-deposit"
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs shadow-lg shadow-emerald-500/25 transition cursor-pointer flex items-center justify-center gap-2 shrink-0"
                >
                  <FileCheck className="w-4 h-4" />
                  <span>Submit for Manual Verification</span>
                </button>
              </div>

              {/* Error / Success Alerts */}
              {errorMsg && (
                <div className="p-3 rounded-xl bg-red-950/50 border border-red-800 text-red-200 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {successMsg && (
                <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2.5">
                  <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block text-white">Under Manual Verification:</span>
                    <span className="text-neutral-300">{successMsg}</span>
                  </div>
                </div>
              )}
            </form>
          </div>

          {/* Transaction History with Screenshot Preview */}
          <div className="bg-neutral-900/90 border border-neutral-800/90 rounded-2xl p-5 shadow-xl space-y-3.5">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <History className="w-4 h-4 text-emerald-400" /> Recent Deposit Transactions
              </span>
              <div className="flex items-center gap-2">
                {onNavigateToTransactions && (
                  <button
                    type="button"
                    onClick={onNavigateToTransactions}
                    className="text-[11px] text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 cursor-pointer transition hover:underline"
                  >
                    <span>View All Transactions →</span>
                  </button>
                )}
                <span className="text-xs text-neutral-400 font-mono">
                  {transactions.length} Records
                </span>
              </div>
            </div>

            <div className="space-y-2.5 max-h-[360px] overflow-y-auto pr-1">
              {transactions.length === 0 ? (
                <div className="py-8 text-center text-xs text-neutral-500">
                  No deposits yet. Scan the QR code to add your first fund.
                </div>
              ) : (
                transactions.map((tx) => {
                  const isPending = tx.status === 'Pending';
                  return (
                    <div
                      key={tx.id}
                      className={`p-3 rounded-xl bg-neutral-950 border transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs ${
                        isPending
                          ? 'border-amber-500/30 bg-amber-500/5'
                          : 'border-neutral-800/80 hover:border-neutral-700'
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 font-semibold text-white">
                          <span>{tx.method}</span>
                          <span className="text-[10px] text-emerald-400 font-mono">
                            ({tx.currency})
                          </span>
                          {isPending && (
                            <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono border border-amber-500/30 animate-pulse">
                              ⏳ Awaiting Manual Verification
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-neutral-400 font-mono mt-0.5 truncate">
                          ID: <strong className="text-neutral-200">{tx.transactionId}</strong> • {tx.date}
                        </div>
                        {tx.senderPhone && (
                          <div className="text-[10px] text-neutral-500 font-mono">
                            Sender: {tx.senderPhone} {tx.senderName ? `(${tx.senderName})` : ''}
                          </div>
                        )}
                        {tx.notes && (
                          <div className="text-[10px] text-neutral-500 italic mt-0.5">
                            Note: {tx.notes}
                          </div>
                        )}
                      </div>

                      <div className="text-left sm:text-right shrink-0 flex flex-col sm:items-end gap-1.5">
                        <div className={`font-mono font-black ${isPending ? 'text-amber-400' : 'text-emerald-400'}`}>
                          +Rs. {tx.amount.toLocaleString()} <span className="text-[10px] font-normal text-neutral-500">NPR</span>
                        </div>
                        <div className="flex flex-wrap items-center gap-1.5">
                          {tx.screenshotUrl && (
                            <button
                              type="button"
                              onClick={() => setPreviewImageModal(tx.screenshotUrl!)}
                              className="text-[10px] px-2 py-0.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 flex items-center gap-1 cursor-pointer transition"
                              title="View Attached Screenshot"
                            >
                              <ImageIcon className="w-2.5 h-2.5 text-emerald-400" />
                              <span>Proof</span>
                            </button>
                          )}
                          {isPending ? (
                            <span className="text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30 font-medium flex items-center gap-1">
                              <Clock className="w-2.5 h-2.5" /> Pending Review
                            </span>
                          ) : (
                            <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-medium flex items-center gap-1">
                              <CheckCircle2 className="w-2.5 h-2.5" /> Verified & Added
                            </span>
                          )}
                        </div>

                        {/* Admin Manual Approval Trigger / Simulation */}
                        {isPending && onApproveDeposit && (
                          <button
                            type="button"
                            onClick={() => {
                              onApproveDeposit(tx.id);
                              confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
                            }}
                            className="mt-1 text-[10px] px-2.5 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold transition flex items-center gap-1 cursor-pointer shadow-md"
                            title="Verify and credit fund to user wallet"
                          >
                            <Check className="w-3 h-3" />
                            <span>Approve & Credit Balance</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Enlarged Screenshot Modal Viewer */}
      {previewImageModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl max-w-lg w-full p-5 space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-emerald-400" />
                Payment Proof Screenshot
              </span>
              <button
                onClick={() => setPreviewImageModal(null)}
                className="text-neutral-400 hover:text-white cursor-pointer p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="rounded-xl overflow-hidden bg-neutral-950 border border-neutral-800 flex items-center justify-center max-h-[480px]">
              <img
                src={previewImageModal}
                alt="Payment Receipt Large"
                className="max-h-[460px] w-auto object-contain"
              />
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setPreviewImageModal(null)}
                className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs text-white font-medium cursor-pointer"
              >
                Close Viewer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
