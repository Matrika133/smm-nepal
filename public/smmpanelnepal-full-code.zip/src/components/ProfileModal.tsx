import React, { useState } from 'react';
import {
  X,
  User,
  Mail,
  Phone,
  Key,
  Copy,
  Check,
  Shield,
  Wallet,
  ShoppingCart,
  Calendar,
  LogOut,
  RefreshCw,
  Sparkles,
  Users
} from 'lucide-react';
import { UserAccount } from '../types';

interface ProfileModalProps {
  isOpen: boolean;
  user: UserAccount;
  onClose: () => void;
  onUpdateUser: (updated: Partial<UserAccount>) => void;
  onLogout: () => void;
  onNavigateTab: (tab: any) => void;
}

export function ProfileModal({
  isOpen,
  user,
  onClose,
  onUpdateUser,
  onLogout,
  onNavigateTab,
}: ProfileModalProps) {
  const [copiedKey, setCopiedKey] = useState(false);
  const [fullName, setFullName] = useState(user.fullName || user.username);
  const [email, setEmail] = useState(user.email);
  const [phone, setPhone] = useState(user.phone || '9841000000');
  const [isSaved, setIsSaved] = useState(false);
  const [keyRegenNotice, setKeyRegenNotice] = useState(false);

  if (!isOpen) return null;

  const handleCopyKey = () => {
    navigator.clipboard.writeText(user.apiKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const handleRegenerateKey = () => {
    const newKey = `smm_live_np_${Math.random().toString(36).substring(2, 12)}`;
    onUpdateUser({ apiKey: newKey });
    setKeyRegenNotice(true);
    setTimeout(() => setKeyRegenNotice(false), 3000);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({ fullName, email, phone });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl max-w-xl w-full p-5 sm:p-7 shadow-2xl relative my-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-2 rounded-full bg-neutral-800/80 hover:bg-neutral-700 text-neutral-400 hover:text-white transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header Profile Overview */}
        <div className="flex items-center gap-4 pb-5 border-b border-neutral-800">
          <div className="h-14 w-14 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 p-0.5 shadow-lg shadow-emerald-500/20 shrink-0">
            <div className="h-full w-full bg-neutral-950 rounded-[14px] flex items-center justify-center text-lg font-black text-emerald-400">
              {user.username.substring(0, 2).toUpperCase()}
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black text-white">{user.fullName || user.username}</h2>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400">
                ⭐ {user.tier}
              </span>
            </div>
            <div className="text-xs text-neutral-400 font-mono flex items-center gap-2 mt-0.5">
              <span>@{user.username}</span>
              <span>•</span>
              <span className="text-emerald-400 font-semibold">Rs. {user.balance.toLocaleString()} NPR</span>
            </div>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-2.5 py-4 border-b border-neutral-800 text-center">
          <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800">
            <span className="text-[10px] text-neutral-500 block">Total Spent</span>
            <span className="text-xs sm:text-sm font-mono font-bold text-white">
              Rs. {user.totalSpent.toLocaleString()}
            </span>
          </div>
          <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800">
            <span className="text-[10px] text-neutral-500 block">Total Orders</span>
            <span className="text-xs sm:text-sm font-mono font-bold text-emerald-400">
              {user.totalOrders}
            </span>
          </div>
          <div className="p-2.5 rounded-xl bg-neutral-950 border border-neutral-800">
            <span className="text-[10px] text-neutral-500 block">Joined</span>
            <span className="text-xs sm:text-sm font-mono font-medium text-neutral-300">
              {user.createdAt || 'Nov 2025'}
            </span>
          </div>
        </div>

        {/* Edit Profile Form */}
        <form onSubmit={handleSaveProfile} className="space-y-3 py-4 border-b border-neutral-800">
          <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">
            Account Details:
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <div className="space-y-1">
              <label className="text-[10px] text-neutral-400">Full Name</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500 font-sans"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] text-neutral-400">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500 font-mono text-[11px]"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] text-neutral-400">Phone</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500 font-mono text-[11px]"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            {isSaved ? (
              <span className="text-[11px] text-emerald-400 flex items-center gap-1 font-semibold">
                <Check className="w-3.5 h-3.5" /> Profile changes saved!
              </span>
            ) : <span />}
            <button
              type="submit"
              className="px-3.5 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-white transition cursor-pointer"
            >
              Save Profile
            </button>
          </div>
        </form>

        {/* API Key Box */}
        <div className="py-4 border-b border-neutral-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-emerald-400" /> Reseller API Key
            </span>
            <button
              onClick={handleRegenerateKey}
              className="text-[10px] text-neutral-400 hover:text-emerald-400 flex items-center gap-1 cursor-pointer font-mono"
            >
              <RefreshCw className="w-3 h-3" /> Regenerate
            </button>
          </div>

          {keyRegenNotice && (
            <div className="text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-1.5 font-mono">
              ✓ New API key generated successfully!
            </div>
          )}

          <div className="flex items-center gap-2 p-2 rounded-xl bg-neutral-950 border border-neutral-800 font-mono text-xs text-neutral-300">
            <span className="truncate flex-1 text-[11px] text-emerald-400">{user.apiKey}</span>
            <button
              onClick={handleCopyKey}
              className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition cursor-pointer"
            >
              {copiedKey ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Free Plan & Status Assurance */}
        <div className="pt-3 pb-1 flex items-center justify-between text-xs text-neutral-400">
          <span className="flex items-center gap-1.5 text-emerald-400">
            <Shield className="w-3.5 h-3.5" /> 100% Free Account Active
          </span>
          <span className="font-mono text-[11px] text-neutral-500">Tier: {user.tier} VIP</span>
        </div>

        {/* Actions Footer */}
        <div className="mt-4 pt-3 border-t border-neutral-800 flex items-center justify-between">
          <button
            onClick={() => {
              onLogout();
              onClose();
            }}
            className="px-3 py-1.5 rounded-xl bg-red-950/40 hover:bg-red-950/80 border border-red-800/60 text-red-300 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onNavigateTab('add_funds');
              }}
              className="px-4 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs transition cursor-pointer shadow-md shadow-emerald-500/20"
            >
              Deposit Funds
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
