import { useState, useEffect, useRef } from 'react';
import {
  TrendingUp,
  Zap,
  ShoppingCart,
  List,
  Wallet,
  Sparkles,
  LifeBuoy,
  Code,
  LayoutDashboard,
  Shield,
  Menu,
  X,
  Flame,
  Globe,
  Bell,
  RefreshCw,
  LogOut,
  User,
  LogIn,
  UserPlus,
  ChevronDown,
  Settings,
  ShieldCheck,
  Gift,
  AlertTriangle,
  Receipt
} from 'lucide-react';
import {
  INITIAL_USER,
  DEFAULT_USERS,
  SMM_SERVICES,
  INITIAL_ORDERS,
  INITIAL_TRANSACTIONS,
  INITIAL_TICKETS,
  BROADCAST_NOTICES,
  INITIAL_CHILD_PANELS
} from './data/smmData';
import { SMMService, SMMOrder, UserAccount, PaymentTransaction, SupportTicket, ToastNotification, OrderStatus, ChildPanel } from './types';

// Tab Components
import { DashboardTab } from './components/DashboardTab';
import { NewOrderTab } from './components/NewOrderTab';
import { OrdersTab } from './components/OrdersTab';
import { ServicesTab } from './components/ServicesTab';
import { ChildPanelTab } from './components/ChildPanelTab';
import { AddFundsTab } from './components/AddFundsTab';
import { TransactionsTab } from './components/TransactionsTab';
import { ReferralTab } from './components/ReferralTab';
import { ProfileTab } from './components/ProfileTab';
import { AIAdvisorTab } from './components/AIAdvisorTab';
import { SupportTab } from './components/SupportTab';
import { APIDocsTab } from './components/APIDocsTab';
import { AuthModal } from './components/AuthModal';
import { ProfileModal } from './components/ProfileModal';
import { AuthDashboard } from './components/AuthDashboard';
import { ToastNotificationContainer } from './components/ToastNotificationContainer';

export function App() {
  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'new_order' | 'orders' | 'services' | 'child_panel' | 'add_funds' | 'transactions' | 'referrals' | 'profile' | 'ai_advisor' | 'support' | 'api'
  >('dashboard');

  // Load registered users from localStorage or default
  const [availableUsers, setAvailableUsers] = useState<UserAccount[]>(() => {
    const saved = localStorage.getItem('smm_nepal_users');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return DEFAULT_USERS;
      }
    }
    return DEFAULT_USERS;
  });

  // Current active user
  const [user, setUser] = useState<UserAccount>(() => {
    const savedActive = localStorage.getItem('smm_nepal_active_user');
    if (savedActive) {
      try {
        return JSON.parse(savedActive);
      } catch (e) {
        return availableUsers[0] || INITIAL_USER;
      }
    }
    return availableUsers[0] || INITIAL_USER;
  });

  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    const savedStatus = localStorage.getItem('smm_nepal_is_logged_in');
    return savedStatus === 'true';
  });

  const [services, setServices] = useState<SMMService[]>(SMM_SERVICES);
  const [orders, setOrders] = useState<SMMOrder[]>(() => {
    const saved = localStorage.getItem('smm_nepal_orders');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_ORDERS;
      }
    }
    return INITIAL_ORDERS;
  });

  const [transactions, setTransactions] = useState<PaymentTransaction[]>(() => {
    const saved = localStorage.getItem('smm_nepal_transactions');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_TRANSACTIONS;
      }
    }
    return INITIAL_TRANSACTIONS;
  });

  const [tickets, setTickets] = useState<SupportTicket[]>(() => {
    const saved = localStorage.getItem('smm_nepal_tickets');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_TICKETS;
      }
    }
    return INITIAL_TICKETS;
  });

  // Child Panel reseller state - Clean and purged for all users
  const [childPanels, setChildPanels] = useState<ChildPanel[]>(() => {
    try {
      localStorage.removeItem('smm_nepal_child_panels');
    } catch (e) {}
    return [];
  });

  const [notices] = useState(BROADCAST_NOTICES);

  // Real-time Toast Notifications state
  const [toasts, setToasts] = useState<ToastNotification[]>([]);
  const prevOrdersRef = useRef<Map<string, OrderStatus>>(new Map());
  const isFirstMountRef = useRef<boolean>(true);

  // Low balance warning state
  const [isLowBalance, setIsLowBalance] = useState<boolean>(false);

  // Modals state
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authInitialMode, setAuthInitialMode] = useState<'login' | 'register'>('login');
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  // Sync users and active user with localStorage
  useEffect(() => {
    localStorage.setItem('smm_nepal_users', JSON.stringify(availableUsers));
  }, [availableUsers]);

  useEffect(() => {
    localStorage.setItem('smm_nepal_active_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('smm_nepal_is_logged_in', String(isLoggedIn));
  }, [isLoggedIn]);

  // Triggers permanent 'Low Balance' warning banner in navbar if user's balance drops below 50 NPR
  useEffect(() => {
    setIsLowBalance(user.balance < 50);
  }, [user.balance]);

  // Sync orders with localStorage and detect real-time status transitions for toast notifications
  useEffect(() => {
    localStorage.setItem('smm_nepal_orders', JSON.stringify(orders));

    if (isFirstMountRef.current) {
      // First mount: initialize tracking map with existing order statuses without alerting
      orders.forEach((ord) => {
        prevOrdersRef.current.set(ord.id, ord.status);
      });
      isFirstMountRef.current = false;
      return;
    }

    // Check for status changes in orders
    const newToasts: ToastNotification[] = [];
    const currentOrderMap = new Map<string, OrderStatus>();

    orders.forEach((ord) => {
      currentOrderMap.set(ord.id, ord.status);
      const prevStatus = prevOrdersRef.current.get(ord.id);

      if (prevStatus && prevStatus !== ord.status) {
        // Pending -> In progress
        if (prevStatus === 'Pending' && ord.status === 'In progress') {
          newToasts.push({
            id: `toast-${Date.now()}-${ord.id}-prog`,
            orderId: ord.orderId,
            serviceName: ord.serviceName,
            previousStatus: prevStatus,
            newStatus: ord.status,
            title: `Order #${ord.orderId} is now In Progress`,
            message: `Dispatching ${ord.quantity.toLocaleString()} units for "${ord.serviceName}". Speed: High-Speed Node.`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            type: 'in_progress',
          });
        }
        // Pending or In progress -> Completed
        else if (
          (prevStatus === 'Pending' || prevStatus === 'In progress' || prevStatus === 'Processing') &&
          ord.status === 'Completed'
        ) {
          newToasts.push({
            id: `toast-${Date.now()}-${ord.id}-comp`,
            orderId: ord.orderId,
            serviceName: ord.serviceName,
            previousStatus: prevStatus,
            newStatus: ord.status,
            title: `Order #${ord.orderId} Completed!`,
            message: `Your order for "${ord.serviceName}" has finished with 100% successful delivery.`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            type: 'completed',
          });
        }
      }
    });

    if (newToasts.length > 0) {
      setToasts((prev) => [...newToasts, ...prev].slice(0, 5));
    }

    // Update ref with latest map
    prevOrdersRef.current = currentOrderMap;
  }, [orders]);

  // Auto-dismiss the oldest toast notification after 6 seconds
  useEffect(() => {
    if (toasts.length === 0) return;
    const timer = setTimeout(() => {
      setToasts((prev) => prev.slice(0, prev.length - 1));
    }, 6000);
    return () => clearTimeout(timer);
  }, [toasts]);

  useEffect(() => {
    localStorage.setItem('smm_nepal_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('smm_nepal_tickets', JSON.stringify(tickets));
  }, [tickets]);

  useEffect(() => {
    localStorage.setItem('smm_nepal_child_panels', JSON.stringify(childPanels));
  }, [childPanels]);

  // Toast handlers
  const handleDismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const handleClearAllToasts = () => {
    setToasts([]);
  };

  const handleViewOrderFromToast = (orderId: number) => {
    setActiveTab('orders');
  };

  // Auth Handlers
  const handleLogin = (authenticatedUser: UserAccount) => {
    setUser(authenticatedUser);
    setIsLoggedIn(true);
    setActiveTab('dashboard');
    // update in available users list if updated
    setAvailableUsers((prev) =>
      prev.map((u) => (u.id === authenticatedUser.id ? authenticatedUser : u))
    );
  };

  const handleRegister = (newUser: UserAccount) => {
    setAvailableUsers((prev) => [newUser, ...prev]);
    setUser(newUser);
    setIsLoggedIn(true);
    setActiveTab('dashboard');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserDropdownOpen(false);
  };

  const handleUpdateUserProfile = (updatedFields: Partial<UserAccount>) => {
    setUser((prev) => {
      const updated = { ...prev, ...updatedFields };
      setAvailableUsers((users) =>
        users.map((u) => (u.id === updated.id ? updated : u))
      );
      return updated;
    });
  };

  // Place Order Handler
  const handlePlaceOrder = (
    orderData: Omit<SMMOrder, 'id' | 'orderId' | 'status' | 'createdAt' | 'startCount' | 'remains'>
  ) => {
    if (!isLoggedIn) {
      setAuthInitialMode('login');
      setAuthModalOpen(true);
      return false;
    }

    if (user.balance < orderData.charge) {
      return false;
    }

    // Deduct balance
    const updatedUser = {
      ...user,
      balance: user.balance - orderData.charge,
      totalSpent: user.totalSpent + orderData.charge,
      totalOrders: user.totalOrders + 1,
    };
    setUser(updatedUser);
    setAvailableUsers((prev) =>
      prev.map((u) => (u.id === updatedUser.id ? updatedUser : u))
    );

    // Create new order record
    const newOrderId = Math.floor(8926 + Math.random() * 800);
    const newOrder: SMMOrder = {
      ...orderData,
      id: `ord-${newOrderId}`,
      orderId: newOrderId,
      startCount: Math.floor(100 + Math.random() * 5000),
      remains: orderData.quantity,
      status: 'Pending',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
    };

    setOrders((prev) => [newOrder, ...prev]);

    // Record Order Debit in Transactions Ledger
    const orderTx: PaymentTransaction = {
      id: `tx-ord-${Date.now()}`,
      userId: user.id,
      type: 'Debit',
      method: 'Wallet Debit',
      amount: orderData.charge,
      currency: 'NPR',
      fee: 0,
      status: 'Completed',
      transactionId: `ORD-${newOrderId}`,
      notes: `Order #${newOrderId}: ${orderData.serviceName} (${orderData.quantity.toLocaleString()} Qty)`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };
    setTransactions((prev) => [orderTx, ...prev]);

    // Simulate order progression to In Progress after 3.5 seconds
    setTimeout(() => {
      setOrders((currOrders) =>
        currOrders.map((o) =>
          o.id === newOrder.id ? { ...o, status: 'In progress', remains: Math.floor(o.quantity * 0.75) } : o
        )
      );
    }, 3500);

    // Simulate order progression to Completed after 8.5 seconds
    setTimeout(() => {
      setOrders((currOrders) =>
        currOrders.map((o) =>
          o.id === newOrder.id ? { ...o, status: 'Completed', remains: 0 } : o
        )
      );
    }, 8500);

    return true;
  };

  // Add Funds Handler (Submitted for Manual Verification)
  const handleAddFunds = (
    amount: number,
    method: PaymentTransaction['method'],
    txId: string,
    extra?: {
      senderName?: string;
      senderPhone?: string;
      screenshotUrl?: string;
      notes?: string;
      isImmediateApproval?: boolean;
    }
  ) => {
    const isImmediate = extra?.isImmediateApproval === true;

    if (isImmediate) {
      const updatedUser = {
        ...user,
        balance: user.balance + amount,
      };
      setUser(updatedUser);
      setAvailableUsers((prev) =>
        prev.map((u) => (u.id === updatedUser.id ? updatedUser : u))
      );
    }

    const newTx: PaymentTransaction = {
      id: `tx-${Date.now()}`,
      method,
      amount,
      currency: 'NPR',
      fee: 0,
      status: isImmediate ? 'Completed' : 'Pending',
      transactionId: txId,
      senderName: extra?.senderName,
      senderPhone: extra?.senderPhone,
      screenshotUrl: extra?.screenshotUrl,
      notes: extra?.notes,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };

    setTransactions((prev) => [newTx, ...prev]);
  };

  // Manual Approval / Verification Handler for Pending Deposits
  const handleApproveDeposit = (txId: string) => {
    const targetTx = transactions.find((t) => t.id === txId || t.transactionId === txId);
    if (!targetTx || targetTx.status === 'Completed') return;

    const updatedUser = {
      ...user,
      balance: user.balance + targetTx.amount,
    };
    setUser(updatedUser);
    setAvailableUsers((prev) =>
      prev.map((u) => (u.id === updatedUser.id ? updatedUser : u))
    );

    setTransactions((prev) =>
      prev.map((t) =>
        t.id === targetTx.id ? { ...t, status: 'Completed' as const } : t
      )
    );
  };

  // Refill Order Handler
  const handleRefillOrder = (orderId: number) => {
    alert(`Refill request for Order #${orderId} has been submitted to automated API node.`);
  };

  // Quick Order from Services / Dashboard
  const handleSelectServiceToOrder = (service: SMMService) => {
    setActiveTab('new_order');
  };

  // Support Ticket Handlers
  const handleCreateTicket = (subject: string, orderId?: number, initialMessage?: string) => {
    const newNum = Math.floor(4022 + Math.random() * 500);
    const newTkt: SupportTicket = {
      id: `tkt-${Date.now()}`,
      ticketNumber: newNum,
      subject,
      orderId,
      status: 'Open',
      priority: 'Medium',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      updatedAt: 'Just now',
      messages: initialMessage
        ? [
            {
              sender: 'user',
              text: initialMessage,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            },
          ]
        : [],
    };

    setTickets((prev) => [newTkt, ...prev]);
  };

  const handleAddTicketMessage = (ticketId: string, text: string) => {
    setTickets((prev) =>
      prev.map((t) => {
        if (t.id === ticketId) {
          const isAiResponse = text.includes('Hello!') || text.includes('Order') || text.includes('refill') || text.length > 80;
          return {
            ...t,
            updatedAt: 'Just now',
            status: isAiResponse ? 'Answered' : 'Open',
            messages: [
              ...t.messages,
              {
                sender: isAiResponse ? 'ai_agent' : 'user',
                text,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              },
            ],
          };
        }
        return t;
      })
    );
  };

  // Child Panel Reseller Handlers
  const handleCreateChildPanel = (panelData: Omit<ChildPanel, 'id' | 'createdAt' | 'renewDate' | 'totalOrdersForwarded' | 'totalEarningsNPR' | 'syncedServicesCount'>): boolean => {
    if (user.balance < panelData.priceMonthly) {
      return false;
    }

    const updatedBalance = user.balance - panelData.priceMonthly;
    const updatedUser: UserAccount = {
      ...user,
      balance: updatedBalance,
      totalSpent: user.totalSpent + panelData.priceMonthly,
    };
    setUser(updatedUser);
    setAvailableUsers((prev) =>
      prev.map((u) => (u.id === updatedUser.id ? updatedUser : u))
    );

    const now = new Date();
    const renew = new Date();
    renew.setDate(now.getDate() + 30);

    const newPanel: ChildPanel = {
      ...panelData,
      id: `cp_${Date.now()}`,
      userId: user.id,
      createdAt: now.toISOString().split('T')[0],
      renewDate: renew.toISOString().split('T')[0],
      totalOrdersForwarded: 0,
      totalEarningsNPR: 0,
      syncedServicesCount: services.length,
    };

    setChildPanels((prev) => [newPanel, ...prev]);

    // Record Payment Transaction for Child Panel Hosting License
    const rentTx: PaymentTransaction = {
      id: `tx-cp-${Date.now()}`,
      method: 'eSewa',
      amount: panelData.priceMonthly,
      currency: 'NPR',
      fee: 0,
      status: 'Completed',
      transactionId: `CP-HOST-${Date.now().toString().slice(-6)}`,
      notes: `Child Panel Hosting License for ${panelData.domain} (30 Days)`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };
    setTransactions((prev) => [rentTx, ...prev]);

    return true;
  };

  const handleRenewChildPanel = (panelId: string): boolean => {
    const target = childPanels.find((p) => p.id === panelId);
    if (!target) return false;

    if (user.balance < target.priceMonthly) {
      alert(`Insufficient funds to renew child panel. Balance: Rs. ${user.balance.toLocaleString()} NPR, Needed: Rs. ${target.priceMonthly.toLocaleString()} NPR.`);
      return false;
    }

    const updatedBalance = user.balance - target.priceMonthly;
    const updatedUser: UserAccount = {
      ...user,
      balance: updatedBalance,
      totalSpent: user.totalSpent + target.priceMonthly,
    };
    setUser(updatedUser);
    setAvailableUsers((prev) =>
      prev.map((u) => (u.id === updatedUser.id ? updatedUser : u))
    );

    const renew = new Date();
    renew.setDate(renew.getDate() + 30);

    setChildPanels((prev) =>
      prev.map((p) =>
        p.id === panelId
          ? { ...p, renewDate: renew.toISOString().split('T')[0], status: 'Active' as const }
          : p
      )
    );

    const rentTx: PaymentTransaction = {
      id: `tx-cp-renew-${Date.now()}`,
      method: 'eSewa',
      amount: target.priceMonthly,
      currency: 'NPR',
      fee: 0,
      status: 'Completed',
      transactionId: `CP-RENEW-${Date.now().toString().slice(-6)}`,
      notes: `Child Panel Renewal for ${target.domain} (+30 Days)`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };
    setTransactions((prev) => [rentTx, ...prev]);

    alert(`Child panel ${target.domain} successfully renewed for 30 days!`);
    return true;
  };

  const handleToggleAutoRenewChildPanel = (panelId: string) => {
    setChildPanels((prev) =>
      prev.map((p) => (p.id === panelId ? { ...p, autoRenew: !p.autoRenew } : p))
    );
  };

  const handleUpdateChildPanelMargin = (panelId: string, marginPercent: number) => {
    setChildPanels((prev) =>
      prev.map((p) => (p.id === panelId ? { ...p, profitMarginPercent: marginPercent } : p))
    );
  };

  // If not logged in, only show the Login and Registration Dashboard
  if (!isLoggedIn) {
    return (
      <AuthDashboard
        availableUsers={availableUsers}
        onLogin={handleLogin}
        onRegister={handleRegister}
      />
    );
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Navbar */}
      <header className="sticky top-0 z-40 bg-neutral-950/90 backdrop-blur-md border-b border-neutral-800/80 px-4 sm:px-8 py-3.5">
        {/* Permanent Low Balance Warning Banner */}
        {isLowBalance && (
          <div
            id="low-balance-navbar-banner"
            role="alert"
            className="max-w-7xl mx-auto mb-3 bg-gradient-to-r from-red-950/90 via-amber-950/80 to-red-950/90 border border-amber-500/60 rounded-xl p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg shadow-red-950/40 animate-in fade-in slide-in-from-top-2 duration-300"
          >
            <div className="flex items-center gap-2.5">
              <div className="h-7 w-7 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                <AlertTriangle className="w-4 h-4 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-500/30">
                    Low Balance Warning
                  </span>
                  <span className="text-xs font-mono font-bold text-red-400">
                    Rs. {user.balance.toLocaleString()} NPR
                  </span>
                </div>
                <p className="text-xs text-neutral-300 mt-0.5">
                  Your account balance has dropped below <strong>50 NPR</strong>. Auto-processing and instant dispatch may be paused until topped up.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setActiveTab('add_funds')}
              className="shrink-0 px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded-lg transition shadow-md shadow-amber-500/20 flex items-center gap-1.5 cursor-pointer ml-auto sm:ml-0"
            >
              <Wallet className="w-3.5 h-3.5" />
              <span>Add Funds (eSewa / Khalti)</span>
            </button>
          </div>
        )}

        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 p-0.5 shadow-lg shadow-emerald-500/20">
              <div className="h-full w-full bg-neutral-950 rounded-[10px] flex items-center justify-center">
                <Zap className="w-5 h-5 text-emerald-400 fill-emerald-400" />
              </div>
            </div>
            <div>
              <h1 className="text-base font-black text-white tracking-tight flex items-center gap-1.5">
                SMM PANEL <span className="text-emerald-400">PRO</span>
              </h1>
              <p className="text-[11px] text-neutral-400 font-mono hidden sm:block">
                Automated Social Media Reseller Engine • NPR
              </p>
            </div>
          </div>

          {/* User Status / Balance / Profile Dropdown (Desktop) */}
          <div className="hidden md:flex items-center gap-3">
            {/* Realtime Live Money / Balance Badge */}
            <div
              className={`flex items-center gap-2.5 px-3.5 py-1.5 rounded-xl bg-neutral-900 border shadow-inner transition ${
                isLowBalance ? 'border-amber-500/60 bg-amber-950/20' : 'border-neutral-800'
              }`}
            >
              <div
                className={`h-2 w-2 rounded-full ${
                  isLowBalance ? 'bg-amber-400 animate-ping' : 'bg-emerald-400 animate-pulse'
                }`}
              />
              <div className="text-right">
                <span className="text-[10px] text-neutral-400 block font-mono">Live Money</span>
                <span
                  className={`text-xs font-mono font-black ${
                    isLowBalance ? 'text-amber-400' : 'text-emerald-400'
                  }`}
                >
                  Rs. {user.balance.toLocaleString()} NPR
                </span>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('add_funds')}
                className={`ml-1 p-1 rounded-lg border transition cursor-pointer text-[11px] font-bold px-2 ${
                  isLowBalance
                    ? 'bg-amber-500 text-neutral-950 border-amber-400 hover:bg-amber-400'
                    : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                }`}
              >
                + Add Funds
              </button>
            </div>

            {/* User Profile Pill & Dropdown */}
            <div className="relative">
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2.5 pl-2.5 pr-2 py-1 rounded-xl bg-neutral-900 hover:bg-neutral-800/80 border border-neutral-800 transition cursor-pointer"
              >
                <div className="h-7 w-7 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-xs font-bold text-emerald-400">
                  {user.username.substring(0, 2).toUpperCase()}
                </div>
                <div className="text-left">
                  <span className="text-xs font-bold text-neutral-200 block truncate max-w-[110px]">
                    @{user.username}
                  </span>
                  <span className="text-[9px] text-amber-400 font-mono font-semibold">
                    ⭐ {user.tier}
                  </span>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-neutral-400" />
              </button>

              {/* Dropdown Menu */}
              {userDropdownOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-neutral-900 border border-neutral-800 rounded-2xl p-1.5 shadow-2xl z-50 animate-in fade-in zoom-in-95">
                  <div className="px-3 py-2 border-b border-neutral-800/80 mb-1">
                    <div className="text-xs font-bold text-white truncate">
                      {user.fullName || user.username}
                    </div>
                    <div className="text-[10px] text-neutral-400 font-mono truncate">
                      {user.email}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setActiveTab('profile');
                      setUserDropdownOpen(false);
                    }}
                    className="w-full px-3 py-2 text-left text-xs font-semibold text-neutral-300 hover:text-white hover:bg-neutral-800 rounded-xl flex items-center gap-2 cursor-pointer"
                  >
                    <User className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Manage Profile & Settings</span>
                  </button>

                  <button
                    onClick={() => {
                      setActiveTab('referrals');
                      setUserDropdownOpen(false);
                    }}
                    className="w-full px-3 py-2 text-left text-xs font-semibold text-neutral-300 hover:text-white hover:bg-neutral-800 rounded-xl flex items-center gap-2 cursor-pointer"
                  >
                    <Gift className="w-3.5 h-3.5 text-amber-400" />
                    <span>Affiliate & Referrals (1.8%)</span>
                  </button>

                  <div className="border-t border-neutral-800/80 my-1" />

                  <button
                    onClick={handleLogout}
                    className="w-full px-3 py-2 text-left text-xs font-semibold text-red-400 hover:bg-red-950/40 rounded-xl flex items-center gap-2 cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Mobile Menu Quick Realtime Money & Trigger */}
          <div className="flex md:hidden items-center gap-2">
            <div
              onClick={() => setActiveTab('add_funds')}
              className={`px-2.5 py-1 rounded-lg border font-bold text-xs font-mono flex items-center gap-1.5 cursor-pointer transition ${
                isLowBalance
                  ? 'bg-amber-950/40 border-amber-500/60 text-amber-400'
                  : 'bg-neutral-900 border-neutral-800 text-emerald-400'
              }`}
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  isLowBalance ? 'bg-amber-400 animate-ping' : 'bg-emerald-400 animate-pulse'
                }`}
              />
              <span>Rs. {user.balance.toLocaleString()}</span>
            </div>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-300"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="max-w-7xl mx-auto mt-3 overflow-x-auto scrollbar-none hidden md:flex items-center gap-1.5 border-t border-neutral-800/80 pt-2.5">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'new_order', label: 'New Order', icon: Zap },
            { id: 'orders', label: 'Order History', icon: ShoppingCart },
            { id: 'services', label: 'Services & Rates', icon: List },
            { id: 'child_panel', label: 'Child Panel', icon: Globe },
            { id: 'add_funds', label: 'Add Funds', icon: Wallet },
            { id: 'transactions', label: 'Transactions', icon: Receipt },
            { id: 'referrals', label: 'Referral System (1.8%)', icon: Gift },
            { id: 'profile', label: 'Profile', icon: User },
            { id: 'ai_advisor', label: 'AI Strategist', icon: Sparkles },
            { id: 'support', label: 'Support Tickets', icon: LifeBuoy },
            { id: 'api', label: 'Reseller API', icon: Code },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 whitespace-nowrap transition cursor-pointer ${
                  isActive
                    ? 'bg-emerald-500 text-neutral-950 font-bold shadow-lg shadow-emerald-500/20'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-900/80'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-neutral-950' : 'text-neutral-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden pt-3 border-t border-neutral-800 mt-3 space-y-3">
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
                { id: 'new_order', label: 'New Order', icon: Zap },
                { id: 'orders', label: 'Order History', icon: ShoppingCart },
                { id: 'services', label: 'Services', icon: List },
                { id: 'child_panel', label: 'Child Panel', icon: Globe },
                { id: 'add_funds', label: 'Add Funds', icon: Wallet },
                { id: 'transactions', label: 'Transactions', icon: Receipt },
                { id: 'referrals', label: 'Referrals (1.8%)', icon: Gift },
                { id: 'profile', label: 'Profile Management', icon: User },
                { id: 'ai_advisor', label: 'AI Strategist', icon: Sparkles },
                { id: 'support', label: 'Support', icon: LifeBuoy },
                { id: 'api', label: 'Reseller API', icon: Code },
              ].map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveTab(tab.id as any);
                      setMobileMenuOpen(false);
                    }}
                    className={`p-2.5 rounded-xl text-xs font-medium flex items-center gap-2 ${
                      isActive
                        ? 'bg-emerald-500 text-neutral-950 font-bold'
                        : 'bg-neutral-900 text-neutral-300'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Mobile Auth Actions */}
            <div className="pt-2 border-t border-neutral-800 flex items-center justify-between gap-2">
              <button
                onClick={() => {
                  setActiveTab('profile');
                  setMobileMenuOpen(false);
                }}
                className="flex-1 py-2 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-xs font-semibold text-neutral-200 flex items-center justify-center gap-1.5"
              >
                <User className="w-3.5 h-3.5 text-emerald-400" />
                <span>@{user.username} Profile</span>
              </button>
              <button
                onClick={() => {
                  handleLogout();
                  setMobileMenuOpen(false);
                }}
                className="py-2 px-3 rounded-xl bg-red-950/40 border border-red-900/60 text-xs font-semibold text-red-300 flex items-center gap-1"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Main Content View */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'dashboard' && (
          <DashboardTab
            user={user}
            orders={orders}
            services={services}
            notices={notices}
            onNavigateTab={setActiveTab}
            onQuickOrder={handleSelectServiceToOrder}
          />
        )}

        {activeTab === 'new_order' && (
          <NewOrderTab
            services={services}
            user={user}
            onPlaceOrder={handlePlaceOrder}
            onSelectServiceDetails={handleSelectServiceToOrder}
          />
        )}

        {activeTab === 'orders' && (
          <OrdersTab
            orders={orders}
            onRefillOrder={handleRefillOrder}
            onNavigateToNewOrder={() => setActiveTab('new_order')}
          />
        )}

        {activeTab === 'services' && (
          <ServicesTab
            services={services}
            onSelectServiceToOrder={handleSelectServiceToOrder}
          />
        )}

        {activeTab === 'child_panel' && (
          <ChildPanelTab
            user={user}
            childPanels={childPanels.filter((p) => !p.userId || p.userId === user.id)}
            onCreateChildPanel={handleCreateChildPanel}
            onRenewChildPanel={handleRenewChildPanel}
            onToggleAutoRenew={handleToggleAutoRenewChildPanel}
            onUpdateMargin={handleUpdateChildPanelMargin}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'add_funds' && (
          <AddFundsTab
            user={user}
            transactions={transactions}
            onAddFunds={handleAddFunds}
            onApproveDeposit={handleApproveDeposit}
            onNavigateToTransactions={() => setActiveTab('transactions')}
          />
        )}

        {activeTab === 'transactions' && (
          <TransactionsTab
            user={user}
            transactions={transactions}
            onApproveDeposit={handleApproveDeposit}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'referrals' && (
          <ReferralTab
            user={user}
            onAddFunds={handleAddFunds}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileTab
            user={user}
            onUpdateUser={handleUpdateUserProfile}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'ai_advisor' && <AIAdvisorTab />}

        {activeTab === 'support' && (
          <SupportTab
            tickets={tickets}
            orders={orders}
            onCreateTicket={handleCreateTicket}
            onAddTicketMessage={handleAddTicketMessage}
          />
        )}

        {activeTab === 'api' && (
          <APIDocsTab user={user} services={services} />
        )}
      </main>

      {/* Auth Modal (Login / Register / Forgot Password) */}
      <AuthModal
        isOpen={authModalOpen}
        initialMode={authInitialMode}
        availableUsers={availableUsers}
        onClose={() => setAuthModalOpen(false)}
        onLogin={handleLogin}
        onRegister={handleRegister}
      />

      {/* Profile & API Settings Modal */}
      <ProfileModal
        isOpen={profileModalOpen}
        user={user}
        onClose={() => setProfileModalOpen(false)}
        onUpdateUser={handleUpdateUserProfile}
        onLogout={handleLogout}
        onNavigateTab={setActiveTab}
      />

      {/* Toast Notification Container */}
      <ToastNotificationContainer
        toasts={toasts}
        onDismiss={handleDismissToast}
        onViewOrder={handleViewOrderFromToast}
        onClearAll={handleClearAllToasts}
      />

      {/* Footer */}
      <footer className="border-t border-neutral-900 bg-neutral-950 py-6 px-4 text-center text-xs text-neutral-500 font-sans">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-emerald-500 inline-block"></span>
            <span>SMM Panel Nepal • Official Nepalese Rupee (NPR) Reseller Network</span>
          </div>
          <div className="flex items-center gap-4 text-neutral-400 font-mono text-[11px]">
            <span>Payments: Fonepay QR • eSewa • Khalti • ConnectIPS • IME Pay</span>
            <span>•</span>
            <span>24/7 Fast Automated Dispatch</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
export default App;

