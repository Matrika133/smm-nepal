import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Helper to get or lazily initialize GoogleGenAI client
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY environment variable is missing.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// 1. Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    app: 'SMM Panel Pro',
    hasKey: !!process.env.GEMINI_API_KEY,
    timestamp: new Date().toISOString(),
  });
});

// 2. AI SMM Strategy & Campaign Advisor
app.post('/api/ai/growth-advisor', async (req, res) => {
  try {
    const { platform, goal, currentFollowers, targetAudience, budget } = req.body;

    const ai = getGeminiClient();

    const prompt = `You are a world-class Social Media Marketing (SMM) Director and Growth Strategist for an elite SMM Panel platform.
A client is requesting an actionable, high-ROI social media growth strategy and panel service distribution.

Client Parameters:
- Platform: ${platform || 'Instagram'}
- Primary Goal: ${goal || 'Boost viral engagement and gain active followers'}
- Current Audience Size: ${currentFollowers || '1,000'}
- Target Niche: ${targetAudience || 'General / Creators'}
- Budget: $${budget || '25'}

Provide a direct, high-impact growth strategy:
1. Recommended SMM Service Breakdown & Allocation (e.g. % Likes vs Views vs Followers vs Drip-feed timing for algorithm boost).
2. Organic + SMM Hybrid Strategy (Content posting frequency, hooks, hashtags, and retention tricks).
3. Pacing & Drip-Feed Recommendation (How many runs and interval minutes to look 100% organic to the platform algorithm).
4. Safety & Monetization tips.

Format your response cleanly with markdown headings and clear bullet points.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are an expert Social Media Marketing consultant and viral algorithm specialist.',
        temperature: 0.7,
      },
    });

    res.json({ advice: response.text });
  } catch (error: any) {
    console.error('Error in growth advisor:', error);
    res.status(500).json({ error: error.message || 'Failed to generate growth strategy' });
  }
});

// 3. AI Social Media Caption & Viral Hook Generator
app.post('/api/ai/generate-hooks', async (req, res) => {
  try {
    const { platform, topic, tone = 'Viral & Engaging' } = req.body;

    const ai = getGeminiClient();

    const prompt = `Generate 5 viral hooks, 3 high-converting captions, and 20 trending SEO hashtags for:
Platform: ${platform || 'TikTok / Instagram Reels'}
Topic/Niche: ${topic || 'Trending tech & business in Nepal'}
Tone: ${tone}

Return crisp, ready-to-copy text optimized for maximum click-through rate and retention.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
    });

    res.json({ output: response.text });
  } catch (error: any) {
    console.error('Error generating hooks:', error);
    res.status(500).json({ error: error.message || 'Failed to generate hooks' });
  }
});

// 4. AI Support Ticket Assistant
app.post('/api/ai/ticket-assist', async (req, res) => {
  try {
    const { orderDetails, userQuestion } = req.body;

    const ai = getGeminiClient();

    const prompt = `You are a helpful, professional, and friendly 24/7 SMM Support Specialist.
Order Context:
${JSON.stringify(orderDetails || {})}

User Inquiry:
"${userQuestion}"

Provide a concise, reassuring, and technically accurate customer support answer. Explain typical delivery speeds, refill policies, or link troubleshooting if applicable.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
    });

    res.json({ reply: response.text });
  } catch (error: any) {
    console.error('Error in ticket assist:', error);
    res.status(500).json({ error: error.message || 'Failed to generate support reply' });
  }
});

// Start Server with Vite middleware for dev / static for prod
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true, host: '0.0.0.0', port: PORT },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 SMM Panel Pro Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
